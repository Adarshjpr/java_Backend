package com.example.QuoteBook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuoteBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
